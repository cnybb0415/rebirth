@echo off
setlocal
set "DEST=%USERPROFILE%\.codex\pets"
if defined CODEX_HOME set "DEST=%CODEX_HOME%\pets"
if not exist "%DEST%" mkdir "%DEST%"
xcopy "%~dp0pets" "%DEST%" /E /I /Y
if errorlevel 1 goto fail
echo.
echo [OK] exo-mungchiz pets installed to: %DEST%
echo Open ChatGPT app - Settings - Pets - Refresh, then pick a member.
echo.
pause
exit /b 0
:fail
echo.
echo [FAIL] Copy failed. Please send a screenshot of this window.
pause
exit /b 1
